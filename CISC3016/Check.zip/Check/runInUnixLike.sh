#!/bin/bash
java -jar Check.jar

